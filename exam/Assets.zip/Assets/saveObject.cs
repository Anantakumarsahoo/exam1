

using System;

[System.Serializable]

public class saveObject
{

    public int num1;

  
}







    // Start is called before the first frame update
 

