﻿/*
 * In this Task you need to perform below tasks.
 * 
 * [ASSETS PATH] * 
 * WEAPON FILES     : ..\Assets\Task 2\3D Assets\SubmachineGuns\
 * WEAPON IMAGE JSON FILE : ..\Assets\WeaponImages.json 
 * ANIMATION FILES  : ..\Assets\Task 2\Animations
 * 
 * [UI PANELS]
 * TODO : Create UI Button Panel for animations. 1.IDLE 2.WALK 3.PICKUP WEAPON 
 * TODO : Create UI Button Panel for waporns.
 * 
 * [CODE]
 * TODO : Download weapon images from the json and show it in weapon ui panel.
 * TODO : Weapon UI Panel only visible once you pick weapon from ground.
 * TODO : Change Weapon by the Weapon UI Button Panel
 * TODO : Change animation by Animation Button Panel. (if you have picked gun then play RIFFLE IDLE animation else idle animation)
 * 
 */
